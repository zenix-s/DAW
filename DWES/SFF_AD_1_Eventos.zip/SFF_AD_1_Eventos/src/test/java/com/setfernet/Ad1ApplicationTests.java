package com.setfernet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ad1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
